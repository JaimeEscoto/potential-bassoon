A Pen created at CodePen.io. You can find this one at https://codepen.io/erevan/pen/zvBKZj.

 Bootstrap + Masonry Gallery from the great work of Justincarroll : https://gist.github.com/justincarroll/5959773. I just codepen it.